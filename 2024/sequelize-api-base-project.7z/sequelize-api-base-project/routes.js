const express = require("express");
const router = express.Router();
const { Event } = require("./models/index");

router.get("/events", async (req, res) => {
  const events = await Event.findAll();
  res.json(events);
});

router.get("/event/:id", async (req, res) => {
  const event = await Event.findByPk(req.params.id);
  res.json(event);
});

router.post("/events", async (req, res) => {
  const idP = req.query.id;
  const event = await User.create({
    id: idP,
    name: req.query.name,
    date: req.query.date,
    description: req.query.description,
  });
  
  res.send(event);
});

module.exports = router;
