const express = require("express");
const router = express.Router();
const { Event } = require("./models");

router.get("/events/:id", (req, res) => {
  const reqId = req.params.id;
  const newEvent = Event.find((event) => event.id == reqId);
  if (newEvent) {
    res.send(newEvent);
  } else {
    res.json({ message: "Evento no encontrado" });
  }
});

module.exports = router;
